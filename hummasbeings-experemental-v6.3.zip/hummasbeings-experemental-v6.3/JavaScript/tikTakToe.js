const cnvs = document.getElementById('Screen');
var bg = cnvs.getcontext('2d');

function drawBg()