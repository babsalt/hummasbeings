<head>
<title>Uploading...</title>
<link rel="stylesheet" href="../style.css">
</head>

<?php
/* database location */
$dbsrc = "hummasserver.db";
/* start database */
$db = new SQLite3($dbsrc, SQLITE3_OPEN_READWRITE);

$id = $_COOKIE['id'];
$userName = $db->querySingle("SELECT user FROM users WHERE userid = $id");

$path = './placeholder/' . $userName;

echo "files:".'</br> </br>';
$count = 0;
foreach($_FILES['userfile']['name'] as $file){
    $newdir = $path . '/' . str_replace(".","",$_POST['dir']) . "/";
    echo ($count + 1).") uploading: $file";
    if (empty($_POST['dir'])){
        echo " ... ";
    }   else{
        echo " to ", (str_replace(".","",$_POST['dir'])), " ... ";
        if (!file_exists($newdir)) {
        mkdir($newdir, 0777, true);
        }
    }

    move_uploaded_file($_FILES['userfile']['tmp_name'][$count], $newdir . $_FILES['userfile']["name"][$count]);
    $count = ($count + 1); 
    echo 'done <br>';
    
} 

    echo ("<meta http-equiv = \"refresh\" content = \"3; url = ./\" />");

?>

<br> You will be redirected back to the main page 3 seconds after files upload. 

<!--

    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,@@@@@@,,,,@@@@@@,,@@@@@@@@@*,,,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,/@@,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,@@(,,,,,,
    ,,,,,,@@%%%%%%%%@@,,,,,,@@%%%%%@@*,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,#@@,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,@@(,,,,,
    ,,,,%%%%%%,,,,%%%%%%,,%%%%%%%%(,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,    

-->
