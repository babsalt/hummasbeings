<?php
    /* database location */
    $dbsrc = "/home/webuser/hummasserver/hummasserver.db";
    /* start database */
    $db = new SQLite3($dbsrc, SQLITE3_OPEN_READWRITE);
    $db->busyTimeout(5000);
    // WAL mode has better control over concurrency.
    // Source: https://www.sqlite.org/wal.html
    $db->exec('PRAGMA journal_mode = wal;');

    /* user folder location */
    $dir = "/home/webuser/userFiles/";

    /* Redirects here after login */
    $redirect_after_login = 'index.php';

    /* salt */
    $salt = "yourafunnycookieryan";

    /* Will not ask password again for */
    $remember_password = strtotime('+30 days'); // 30 days
    $remember_id = strtotime('+30 days'); // 30 days


    if (isset($_POST["userName"])){
    if ($_POST["password"] == $_POST["password2"])
    {   
        if (null == $db->querySingle("SELECT * FROM users WHERE user = '" . $_POST["userName"] . "'"))
        {
            $userName = $_POST["userName"];
            if (null == $db->querySingle("SELECT * FROM users WHERE email = '" . $_POST["email"] . "'"))
            {
                $userid = sprintf("%07d", mt_rand(1, 9999999));
                if (null !== $db->querySingle("SELECT * FROM users WHERE userid = $userid")) {die("Something went wrong. Try again.");}
                $input = "INSERT INTO users VALUES ('" . $_POST['userName'] . "', '" . md5($_POST['password'].$_POST['email']) . "', " . $userid . ", '" . $_POST['email'] . "')";
                if ($db->querySingle($input) !== FALSE) {
                    echo "New user added " . $userid;
                    mkdir(
                        "$dir/$userName",
                        $permissions = 0777,
                    );                   
                    setcookie("password", md5(md5($_POST['password'].$_POST['email']).$salt), $remember_password);
                    setcookie("id", $userid, $remember_id);
                    header('Location: ' . $redirect_after_login);
                    exit;
                  } else {die("Something went wrong. Try again.");}
            } else {
                echo "Email in use";    
            }
        } else {
            echo "Username in use";
        }
    } else {
        echo "Passwords dont match";
    }}
    $db->close();
    unset($db);    
?>  
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <?php require_once('common-page-data.php'); ?>
</head>
<body>
    <form method="post">
        <div class="container">
            <div class="center">
            <label for="userName"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="userName" required>
            <br>
            <br>
            <label for="password"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="password" required>
            <br>
            <br>   
            <label for="password"><b>Re enter Password</b></label>
            <input type="password" placeholder="Enter Password" name="password2" required>
            <br>
            <br>   
            <label for="password"><b>Email</b></label>
            <input type="email" placeholder="Enter Email" name="email" required>
            <br>
            <br>   
            <button type="submit">Login</button>
            </div>
        </div>
    </form>
</body>
<!--

    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,@@@@@@,,,,@@@@@@,,@@@@@@@@@*,,,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,/@@,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,@@(,,,,,,
    ,,,,,,@@%%%%%%%%@@,,,,,,@@%%%%%@@*,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,#@@,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,@@(,,,,,
    ,,,,%%%%%%,,,,%%%%%%,,%%%%%%%%(,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,    

-->
</html>
