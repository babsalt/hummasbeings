<?php
    /* database location */
    $dbsrc = "hummasserver.db";
    /* start database */
    $db = new SQLite3($dbsrc, SQLITE3_OPEN_READWRITE);

    /* salt */
    $salt = "yourafunnycookieryan";

    /* Get db data for user */       
    $id = $_COOKIE['id'];
    $password = $db->querySingle("SELECT password FROM users WHERE userid = $id");
    $star = $db->querySingle("SELECT email FROM users WHERE userid = $id");

    if (empty($_COOKIE['password']) || $_COOKIE['password'] !== md5(md5($password.$star).$salt)) {
        // Password not set or incorrect. Send to login.php.
        header('Location: login.php');
        exit;
    }

/*

    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,@@@@@@,,,,@@@@@@,,@@@@@@@@@*,,,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,/@@,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,@@(,,,,,,
    ,,,,,,@@%%%%%%%%@@,,,,,,@@%%%%%@@*,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,#@@,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,@@(,,,,,
    ,,,,%%%%%%,,,,%%%%%%,,%%%%%%%%(,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,    

*/
?>