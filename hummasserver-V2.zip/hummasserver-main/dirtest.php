<?php 

mkdir(
    "./doesidwork/",
    $permissions = 0777,
)

?> 
