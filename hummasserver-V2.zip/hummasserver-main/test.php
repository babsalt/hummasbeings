<?php

$db = new SQLite3('test.db');

if(!$db) {
  echo $db->lastErrorMsg();
} else {
  echo "Opened database successfully\n";
}

$version = $db->querySingle('SELECT SQLITE_VERSION()');

echo $version . "\n";

$sql = $db->querySingle('SELECT * FROM user');
echo $sql;
