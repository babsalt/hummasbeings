<?php
    /* database location */
    $dbsrc = "hummasserver.db";
    /* start database */
    $db = new SQLite3($dbsrc, SQLITE3_OPEN_READWRITE);

    /* Redirects here after login */
    $redirect_after_login = 'index.php';

    /* Will not ask password again for */
    $remember_password = strtotime('+30 days'); // 30 days
    $remember_id = strtotime('+30 days'); // 30 days

    /* salt */
    $salt = "yourafunnycookieryan";

    /* Get db data for user */
    if (isset($_POST["userName"]))  
    {
        $username = $_POST["userName"];
        $password = $db->querySingle("SELECT password FROM users WHERE user = '$username'");
        $star = $db->querySingle("SELECT email FROM users WHERE user = '$username'");
        $id = $db->querySingle("SELECT userid FROM users WHERE user = '$username'");
    }

    if (isset($_POST['password']) && md5($_POST['password'].$star) == $password) {
        setcookie("password", md5(md5($password.$star).$salt), $remember_password);
        setcookie("id", $id, $remember_id);
        header('Location: ' . $redirect_after_login);
        exit;
    }

?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <?php require_once('common-page-data.php'); ?>
</head>
<body>
    <form method="post">
        <div class="container">
            <div class="center">
            <label for="userName"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="userName" required>
            <br>
            <br>
            <label for="password"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="password" required>
            <br>
            <br>   
            <button type="submit">Login</button>
            </div>
        </div>
    </form>
</body>
<!--

    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,@@@@@@,,,,@@@@@@,,@@@@@@@@@*,,,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,/@@,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,@@(,,,,,,
    ,,,,,,@@%%%%%%%%@@,,,,,,@@%%%%%@@*,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,#@@,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,@@(,,,,,
    ,,,,%%%%%%,,,,%%%%%%,,%%%%%%%%(,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,    

-->
</html>
