<html>
<head>
<?php require_once('protect-this.php'); ?>
<?php require_once('common-page-data.php'); ?>
<title>Upload</title>

</head>

<body>
    <div class="header">
        <h1>Uploader:</h1>
        <form action="logout.php" method="post" enctype="multipart/form-data">  
            <input class="logout" type="submit" value="Logout" />
        </form>
    </div>
    
    This webpage is currently in development, however it is completely functional. Some note on its function: to make a new file just type its name into the "files to upload" space and hit send files. 
    This works regardless of if there is a file to be uploaded. On the note of files, you can upoad up to 25 at a time, however each upload is limited to 40MB total. If a file has the same name of an existing one it will be replaced 
    and there is also no way of deleting files <br><br>

    <form action="upload.php" method="post" enctype="multipart/form-data">    
        folder name (if it is not to go in a folder leave blank) <input type="text" name="dir"><br>
        files to upload <input name="userfile[]" type="file" multiple/>
        <br><br>
        <input style="background-color: white;" type="submit" value="Send files" />
    </form>
    
<div class="list">

    <?php

    /* probe: echo ("<script>console.log('input')</script>"); */

    /* database location */
    $dbsrc = "hummasserver.db";
    /* start database */
    $db = new SQLite3($dbsrc, SQLITE3_OPEN_READWRITE);

    $id = $_COOKIE['id'];
    $userName = $db->querySingle("SELECT user FROM users WHERE userid = $id");

    $path = "./placeholder/$userName";
    $prefix = "placeholder/$userName";

    ListFolder($path, $prefix);

        function ListFolder($path, $prefix){
            //using the opendir function
            $dir_handle = @opendir($path) or die("Unable to open $path");

            //Leave only the lastest folder name
            $explode = explode("/", $path);
            $dirname = end($explode);

            //display the target folder.
            echo ("<li>$dirname\n");
            if (strlen("$dirname") === 0){
                echo ("<hi>Currently Stored: </hi>");
            }
            echo "<ul>\n";
            while (false !== ($file = readdir($dir_handle))) {
                if($file!="." && $file!=".."){
                    if (is_dir($path."/".$file)){
                        //Display a list of sub folders.
                        ListFolder($path."/".$file, $prefix."/".$file);
                        echo ("<script>console.log('$prefix/$file')</script>");
                    }else{
                        //Display a list of files.
                        echo ("<li><a href=./".str_replace(" ","%20","$prefix")."/$file>$file</a></li>");
                    }
                }
            }

            echo "</ul>\n";
            echo "</li>\n";

            //closing the directory
            closedir($dir_handle);
        }
    ?>

</div>
    
</body>
<!--

    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,@@@@@@,,,,@@@@@@,,@@@@@@@@@*,,,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,/@@,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,@@(,,,,,,
    ,,,,,,@@%%%%%%%%@@,,,,,,@@%%%%%@@*,,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,#@@,,,,,
    ,,,,,,@@,,,,,,,,@@,,,,,,@@/,,,,,@@(,,,,,
    ,,,,%%%%%%,,,,%%%%%%,,%%%%%%%%(,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,
    ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,    

-->
</html>
